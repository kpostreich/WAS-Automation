#!/bin/sh

# Usage: ./imcl_ifix_install.sh <version>
# Given that the WebSphere Liberty is installed in the path: /opt/IBM/WebSphere/Liberty<version>

/opt/IBM/InstallationManager/eclipse/tools/imcl install 20.0.0.9-WS-WLP-IFPH29942 \
    -installationDirectory /opt/IBM/WebSphere/Liberty"$1" \
    -repositories /iFix/PH29942/20.0.0.9-WS-WLP-IFPH29942.zip -sP
