#!/bin/sh

# Usage: ./imcl_ifix_uninstal.sh <version>
# Given that the WebSphere Liberty is installed in the path: /opt/IBM/WebSphere/Liberty<version>

/opt/IBM/InstallationManager/eclipse/tools/imcl uninstall 20.0.0.9-WS-WLP-IFPH29942 \
    -installationDirectory /opt/IBM/WebSphere/Liberty"$1" -sP
