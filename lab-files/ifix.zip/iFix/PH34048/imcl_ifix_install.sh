#!/bin/sh

# Usage: ./imcl_ifix_install.sh <version>
# Given that the WebSphere AppServer is installed in the path: /opt/IBM/WebSphere/AppServer<version>

/opt/IBM/InstallationManager/eclipse/tools/imcl install 9.0.5.4-WS-WASPORD-IFPH34048 \
    -installationDirectory /opt/IBM/WebSphere/AppServer"$1" \
    -repositories /iFix/PH34048/9.0.5.4-ws-wasprod-ifph34048.zip -sP
