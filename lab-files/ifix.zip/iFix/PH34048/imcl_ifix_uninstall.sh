#!/bin/sh

# Usage: ./imcl_ifix_uninstall.sh <version>
# Given that the WebSphere AppServer is installed in the path: /opt/IBM/WebSphere/AppServer<version>

/opt/IBM/InstallationManager/eclipse/tools/imcl uninstall 9.0.5.4-WS-WASPORD-IFPH34048 \
    -installationDirectory /opt/IBM/WebSphere/AppServer"$1" -sP
