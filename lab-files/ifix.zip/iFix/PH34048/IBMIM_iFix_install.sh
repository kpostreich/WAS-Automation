#!/bin/sh
/opt/IBM/InstallationManager/eclipse/IBMIM --launcher.ini /opt/IBM/InstallationManager/eclipse/silent-install.ini -input /iFix/PH34048/iFix_install_PH34048.xml
