#!/bin/sh
/opt/IBM/InstallationManager/eclipse/IBMIM --launcher.ini /opt/IBM/InstallationManager/silent-install.ini -input /iFix/PH34048/iFix_uninstall_PH34048.xml
