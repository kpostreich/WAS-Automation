#!/bin/sh

# Usage: ./imcl_ifix_uninstall.sh <version>
# Given that the WebSphere AppServer is installed in the path: /opt/IBM/WebSphere/AppServer<version>

/opt/IBM/InstallationManager/eclipse/tools/imcl uninstall 9.0.0.11-WS-WASProd-IFPH34122 \
    -installationDirectory /opt/IBM/WebSphere/AppServer"$1" -sP
