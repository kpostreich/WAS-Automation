#!/bin/sh
/opt/InstallationManager/eclipse/IBMIM --launcher.ini /opt/InstallationManager/eclipse/silent-install.ini -input /iFix/PH34711/iFix_uninstall_PH34711.xml
