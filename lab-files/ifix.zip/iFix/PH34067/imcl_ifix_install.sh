#!/bin/sh

# Usage: ./imcl_ifix_install.sh <version>
# Given that the WebSphere AppServer is installed in the path: /opt/IBM/WebSphere/AppServer<version>

/opt/IBM/InstallationManager/eclipse/tools/imcl install 9.0.5.0-WS-WASPROD-IFPH34067 \
    -installationDirectory /opt/IBM/WebSphere/AppServer"$1" \
    -repositories /iFix/PH34067/9.0.5.0-ws-wasprod-ifph34067.zip -sP
