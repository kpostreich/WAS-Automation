#!/bin/sh
/opt/IBM/InstallationManager/eclipse/IBMIM --launcher.ini /opt/IBM/InstallationManager/eclipse/silent-install.ini -input /iFix/PH34067/iFix_uninstall_PH34067.xml
