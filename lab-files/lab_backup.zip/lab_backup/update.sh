#!/bin/bash
set -euxo pipefail

oc login --username=ocadmin --password=ibmocp46 --insecure-skip-tls-verify=true --server=https://api.ocp.ibm.edu:6443
oc project websphere-automation

apiKey="$(oc -n websphere-automation get secret automation-secure-metering-apis-encrypted-tokens -o jsonpath='{.data.automation-secure-metering-apis-sa}' | base64 -d)"
url="https://$(oc get route cpd -n websphere-automation -o jsonpath='{.spec.host}')/websphereauto/meteringapi"
usageMetering="<usageMetering url=\"$url\" apiKey=\"$apiKey\" sslRef=\"defaultSSL\" />"
sed -i "s#<usageMetering.*/>#$usageMetering#g" /home/ibmuser/Desktop/lab_backup/liberty20009/server_configured_no_beanvalidation.xml /home/ibmuser/Desktop/lab_backup/liberty20009/server_configured.xml /home/ibmuser/Desktop/lab_backup/server*final.xml
rm -f /home/ibmuser/Desktop/lab_backup/liberty20009/server_configured_no_beanvalidation.xmlE /home/ibmuser/Desktop/lab_backup/liberty20009/server_configured.xmlE /home/ibmuser/Desktop/lab_backup/server*final.xmlE

